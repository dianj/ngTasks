import { Component } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import 'rxjs/add/observable/from';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/zip';
import 'rxjs/add/operator/reduce';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/bufferCount';

@Component({
  selector: 'my-app',
  template: `
  <h1>{{name}}</h1>
  <hr align="left" style="max-width:600px;">
  `,
})
export class AppComponent  {
  name = 'Task 2 (console.log stuff)';

  constructor() {
    // Task 2.1
    this.get$('http://someurl.com')
      .map(data => JSON.parse(data))
      .mergeMap(data => extract(data))
      .subscribe(console.log, console.error);


    // Task 2.2
    const urls = ['http://domain.com', 'http://domain.bg', 'http://domain.eu'];
    Observable.from(urls).mergeMap(url => this.get$(url)).map(data => JSON.parse(data)).subscribe(console.log);



  }

  get$(url: string): Observable<any> {
    return new Observable((observer: Observer<any>) => {
      const request = this.get(url, (err: any, data: any) => {
        if (err) return observer.error(err);
        observer.next(data);
        observer.complete();
      });

      return () => {
        request.cancel();
      };
    });
  }

  get(url: string, callback: any) {
    console.log(`fake get request to ${url}`);
    const id = setTimeout(() => {
      console.log(`get request JSON response`)
      callback(null, `[{
        "name": "Ivan",
        "age": 18
      }, {
        "name": "Petar",
        "age": 25
      }, {
        "name": "Alex",
        "age": 10
      }]`);
    }, 2000);
    return {
      cancel: () => clearInterval(id)
    };
  }

}

//1.1
const numbersA = [10,64,12,32];
let numbersResA: number;
Observable.from(numbersA).reduce((acc, curr) => acc + curr, 0).subscribe(
  function (acc) {
    numbersResA = acc;
  }
);
console.log('1.1 -> sum: '+ numbersResA);

//1.2
const numbersB = [3,7,5,2,8,1];
let numbersResB: string = '';
Observable.from(numbersB).filter(x => x % 2 !== 0).subscribe(data => numbersResB += data + ' ');
console.log('1.2 -> odds: '+ numbersResB);

// 1.3
const users = [{
  name: 'Ivan',
  age: 18
}, {
  name: 'Petar',
  age: 25
}, {
  name: 'Alex',
  age: 10
}];
export const extract = (arr: any[]) => {
  const source$ = Observable.from(arr);
  const names$ = source$.map(u => u.name).bufferCount(arr.length);
  const ages$ = source$.map(u => u.age).bufferCount(arr.length);
  return Observable.zip(names$, ages$, (names: string[], ages: number[]) => ({names, ages}));
};
extract(users).subscribe(x => console.log(x));

