"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var Observable_1 = require('rxjs/Observable');
require('rxjs/add/observable/from');
require('rxjs/add/observable/of');
require('rxjs/add/observable/zip');
require('rxjs/add/operator/reduce');
require('rxjs/add/operator/filter');
require('rxjs/add/operator/map');
require('rxjs/add/operator/mergeMap');
require('rxjs/add/operator/bufferCount');
var AppComponent = (function () {
    function AppComponent() {
        var _this = this;
        this.name = 'Task 2 (console.log stuff)';
        // Task 2.1
        this.get$('http://someurl.com')
            .map(function (data) { return JSON.parse(data); })
            .mergeMap(function (data) { return exports.extract(data); })
            .subscribe(console.log, console.error);
        // Task 2.2
        var urls = ['http://domain.com', 'http://domain.bg', 'http://domain.eu'];
        Observable_1.Observable.from(urls).mergeMap(function (url) { return _this.get$(url); }).map(function (data) { return JSON.parse(data); }).subscribe(console.log);
    }
    AppComponent.prototype.get$ = function (url) {
        var _this = this;
        return new Observable_1.Observable(function (observer) {
            var request = _this.get(url, function (err, data) {
                if (err)
                    return observer.error(err);
                observer.next(data);
                observer.complete();
            });
            return function () {
                request.cancel();
            };
        });
    };
    AppComponent.prototype.get = function (url, callback) {
        console.log("fake get request to " + url);
        var id = setTimeout(function () {
            console.log("get request JSON response");
            callback(null, "[{\n        \"name\": \"Ivan\",\n        \"age\": 18\n      }, {\n        \"name\": \"Petar\",\n        \"age\": 25\n      }, {\n        \"name\": \"Alex\",\n        \"age\": 10\n      }]");
        }, 2000);
        return {
            cancel: function () { return clearInterval(id); }
        };
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            template: "\n  <h1>{{name}}</h1>\n  <hr align=\"left\" style=\"max-width:600px;\">\n  ",
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//1.1
var numbersA = [10, 64, 12, 32];
var numbersResA;
Observable_1.Observable.from(numbersA).reduce(function (acc, curr) { return acc + curr; }, 0).subscribe(function (acc) {
    numbersResA = acc;
});
console.log('1.1 -> sum: ' + numbersResA);
//1.2
var numbersB = [3, 7, 5, 2, 8, 1];
var numbersResB = '';
Observable_1.Observable.from(numbersB).filter(function (x) { return x % 2 !== 0; }).subscribe(function (data) { return numbersResB += data + ' '; });
console.log('1.2 -> odds: ' + numbersResB);
// 1.3
var users = [{
        name: 'Ivan',
        age: 18
    }, {
        name: 'Petar',
        age: 25
    }, {
        name: 'Alex',
        age: 10
    }];
exports.extract = function (arr) {
    var source$ = Observable_1.Observable.from(arr);
    var names$ = source$.map(function (u) { return u.name; }).bufferCount(arr.length);
    var ages$ = source$.map(function (u) { return u.age; }).bufferCount(arr.length);
    return Observable_1.Observable.zip(names$, ages$, function (names, ages) { return ({ names: names, ages: ages }); });
};
exports.extract(users).subscribe(function (x) { return console.log(x); });
//# sourceMappingURL=app.component.js.map