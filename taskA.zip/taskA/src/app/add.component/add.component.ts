import { Component, Input, NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

@NgModule({
  imports: [ BrowserModule ],
  declarations: [ AddComponent ],
  bootstrap: [ AddComponent ]
})

@Component({
  selector: 'add-todo',
  template: `
  <form>
    <input type="text" #todoItem>
    <input type="button" value="ADD" (click)="addTodo(todoItem.value); todoItem.value = '';">
  </form>
  `
})
export class AddComponent  {
  @Input('appData') items: any[];

  addTodo(todoValue: any) {
    if ( todoValue ) {
      this.items.push({
        name: todoValue,
        status: 0
      });
    }
  }
}
