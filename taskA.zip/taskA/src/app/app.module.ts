import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';

import { AddComponent } from './add.component/add.component';
import { ListComponent } from './list.component/list.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, AddComponent, ListComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
