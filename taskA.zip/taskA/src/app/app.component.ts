import { Component, NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

import { AddComponent } from './add.component/add.component';
import { ListComponent } from './list.component/list.component';

@NgModule({
  imports: [ BrowserModule ],
  declarations: [ AppComponent, AddComponent, ListComponent ],
  bootstrap: [ AppComponent ]
})

@Component({
  selector: 'my-app',
  template: `<h1>{{name}}</h1>
  <add-todo [appData]="appData"></add-todo>
  <br>
  <div style="display:table; width: 600px; margin: 20px;">
    <div style="display: table-cell; cursor:pointer; width: 200px; text-align:center; color: blue;" (click)="listItems('all')">All</div>
    <div style="display: table-cell; cursor:pointer; width: 200px; text-align:center; color: green;" (click)="listItems(1)">Active</div>
    <div style="display: table-cell; cursor:pointer; width: 200px; text-align:center; color: red;" (click)="listItems(0)">Inactive</div>
  </div>
  <list-todo [appData]="appData" [appDataList]="appDataList" [filterItems]="filterItems"></list-todo>
  `,
})
export class AppComponent  {
  name = 'TODO APP';
  public items: Task[] = [];
  public listItem: any = 0;
  appData: Task[] = this.items;
  appDataList: any = this.listItem;
  public filterItems: any = this.listItem;

  listItems (i: any) {
    this.filterItems = i;
  }

}

export class Task {
  name: string;
  status: number;
  constructor(_name: string, _status: number) {};
}
