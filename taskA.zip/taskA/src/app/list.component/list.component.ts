import { Component, Input, NgModule } from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';

@NgModule({
  imports: [ BrowserModule ],
  declarations: [ ListComponent ],
  bootstrap: [ ListComponent ]
})

@Component({
  selector: 'list-todo',
  template: `
  <hr align="left" style="max-width:600px;">
  <div  *ngFor="let item of items; let i = index">
    <div *ngIf="filterItem === item.status || filterItem === 'all'" style="cursor:pointer;" (click)="activeStatus(i)">{{item.name}}</div>
  </div>
  `
})
export class ListComponent  {
  @Input('appData') items: any[];
  @Input('appDataList') listItem: any;
  @Input('filterItems') filterItem: any;

  activeStatus(i: number) {
    this.items[i].status === 0 ? this.items[i].status = 1 : this.items[i].status = 0;
  }
}
