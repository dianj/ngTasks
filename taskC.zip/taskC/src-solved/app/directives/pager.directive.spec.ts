/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { PagerDirective } from './pager.directive';

describe('PagerDirective', () => {
  it('should create an instance', () => {
    const directive = new PagerDirective();
    expect(directive).toBeTruthy();
  });
});
